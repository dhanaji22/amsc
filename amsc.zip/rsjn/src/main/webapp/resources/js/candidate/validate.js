(function($,W,D)
{
    var JQUERY4U = {};
 
    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
	            //form validation rules
            $("#candidateForm").validate({
                rules: {
                    firstName: "required",
                      mobile: {
      					required: true,
      					digits: true,
						minlength: 10,
						maxlength:10
   					  },
                      email: {
                        required: true,
                        email: true
                      },
 					  password: {
                        required: true,
                        minlength: 8
                      },
					  confirmPassword: {
                        required: true,
						equalTo:"#password",
                        minlength: 8
                       },
                     agree: "required",
	             },/*end of rules*/
                  messages: {
                    firstName: "Please enter your name",
                    mobile: "Please enter a valid mobile number",
					password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 8 characters long"
                    },
					confirmPassword: {
                        required: "Please type password again",
                        minlength: "Your password must be at least 8 characters long"
                    },
                    email: "Please enter a valid email address",
                    agree: "Please accept our policy"
                },/*end of msgs*/

                submitHandler: function(form) {
                    form.submit();
                }
            }/*end of validat function*/
		  );/*close of validate rsj*/
        }/*end of setup validation function*/
    }/*end of jquery util*/
 
    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });
 
})(jQuery, window, document);