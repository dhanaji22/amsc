﻿(function($,W,D)
{
    var JQUERY4U = {};
 
    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
	            //form validation rules
            $("#candidateForm").validate({
                rules: {
                    firstName: "required",
		    preferredName: "required",
                      mobile: {
      					required: true,
      					digits: true,
						minlength: 10,
						maxlength:10
   					  },
                      email: {
                        required: true,
                        email: true
                      },
		      referenceEmail: {
                       user_email_not_same: true,
                         email: true
                      },
                      currentPassword: {
                        required: true,
                        minlength: 8
                      },
 					  password: {
                        required: true,
                        minlength: 8
                      },
					  passwordC: {
                        required: true,
						equalTo:"#password",
                        minlength: 8
                       },
					 
                     dob: "required",
                     gender: "required",
                     workLocation: {
							selectcheck: true
                    		},
                     agree: "required",
	             },/*end of rules*/
                  messages: {
                    firstName: "Please enter your full name",
		    preferredName: "Please enter the name you prefer to display",
                    mobile: "Please enter a valid mobile number",
                    currentPassword: {
                        required: "Please provide current password",
                        minlength: "Your password must be at least 8 characters long"
                    },
					password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 8 characters long"
                    },
					passwordC: {
                        required: "Please type password again",
                        minlength: "Your password must be at least 8 characters long"
                    },
                    email: "Please enter a valid email address",
                    
                    dob: "Please enter your date of birth",
                    gender: "Please select gender",
                    //location: "Please select location",
                    agree: "Please accept our policy"
                },/*end of msgs*/

                submitHandler: function(form) {
                    form.submit();
                }
            }/*end of validat function*/
		  );/*close of validate rsj*/
        }/*end of setup validation function*/
    }/*end of jquery util*/
    //when the dom has loaded setup form validation rules
$.validator.addMethod("user_email_not_same", function(value, element) {
   return $('#referenceEmail').val() != $('#email').val()
}, "* Reference email and Email should not match");
$.validator.addMethod('selectcheck', function (value) {
    return (value != 'null');
}, "Location required");
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });
 
})(jQuery, window, document);