/* function deleteSkill(id){
		x=document.getElementById(id);
		x.innerHTML=""; 
	} */
	function addSkill() {
		e = document.getElementById("skillVal");
		var v = e.options[e.selectedIndex].value;
		var v1 = e.options[e.selectedIndex].text;
		//adds skill every time its called and gives name as skill+numberI & total skills will be stored in skillCount
		var table=document.getElementById("skillTable");
		skillCount++;
		x = document.getElementById("skillCount");
		x.value++;
		 table.innerHTML += '<tr><td><input type="hidden" value="'+v+'" name="skillh'+x.value+'">'+
		 				'<select class="form-control" name="skill'+x.value+'"><option value="'+v+'">'+
		 				v1+
		 				'</option><select><td><tr>';
				 //increments skillCount value
	}
	function addQualification(){
		x=document.getElementById("qualificationTable");
		x1=document.getElementById("eduCountM");
		x1.value++;
		var expCount=x1.value;
		x.innerHTML +='<tr><td><select class="form-control" id="year'+expCount+'" type="text" name="year'+expCount+'" ></select></td>'+
			'<td><input type="hidden" name="degreeh'+expCount+'" value="-4">'+//id
			    '<select id="degree" class="form-control" type="text" name="degree'+expCount+'">'+
							 	'<c:forEach items="${degreeList}" var="m">'+
									'<Option value="${m.getId()}">'+
										'${m.getName()}'+
									'</Option>'+
								'</c:forEach>'+
			    ' </select></td>'+
			'<td><input type="hidden" name="fieldh'+expCount+'" value="-4">'+//id
			'<select id="field" class="form-control" type="text" name="field'+expCount+'">'+
							 	'<c:forEach items="${fieldList}" var="m">'+
									'<Option value="${m.getId()}">'+
										'${m.getName()}'+
									'</Option>'+
								'</c:forEach>'+
			'</select></td>'+
			'<td><input type="hidden" name="streamh'+expCount+'" value="-4">'+//id
			'<select id="stream" class="form-control" type="text" name="stream'+expCount+'" >'+
							 	'<c:forEach items="${streamList}" var="m">'+
									'<Option value="${m.getStreamId()}">'+
										'${m.getStreamName()}'+
									'</Option>'+
								'</c:forEach>'+
			'</select></td> '+
			'<td><input class="form-control" type="text" name="marks'+expCount+'" required></td>'+
			'<td><input class="form-control" type="text" name="institute'+expCount+'" ></td>'+			
			'<td><input class="form-control" type="text" name="university'+expCount+'" ></td>'+
		'</tr>';
		addYears("year"+expCount);
	}
	/* function addWorkExperience(){
		alert("works");
	} */
	function addYears(idName){
		option=document.getElementById(idName);
		for(i=1980;i<2015;i++){
			option.innerHTML +='<option value="'+i+'"> '+i+'</option>';
		}
	}
	function addWorkExperience(){
		x=document.getElementById("workTable");
		x1=document.getElementById("expCount");
		x1.value++;
		expCount=x1.value;
		x.innerHTML +='<tr><input type="hidden" name="workExpId'+expCount+'" value="-4"><td><input class="form-control" type="text" name="companyName'+expCount+'" required> </td>'+
			'<td><input class="form-control" type="date" name="from'+expCount+'" required></td>'+
			'<td><input class="form-control" type="date" name="to'+expCount+'" required></td> '+
			'<td><input class="form-control" type="number" name="ctc'+expCount+'"  required></td>'+
			'<td><input class="form-control" type="text" name="description'+expCount+'" ></td>'+			
		'</tr>';	
	}
