(function($,W,D)
{
    var JQUERY4U = {};
 
    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
	            //form validation rules
            $("#uploadForm").validate({
                rules: {
                    resume: {
	required: true
	/*accept: "pdf"*/
}
	                },
                messages: {
                    resume: "Please upload an authorized letter on your company letter head ",
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }
 
    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });
 
})(jQuery, window, document);