(function($,W,D)
{
    var JQUERY4U = {}
 
    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
	            //form validation rules
            $("#rsjEmployer").validate({
                rules: {
                    name: "required",
                      mobile: {
      					required: true,
      					digits: true,
						minlength: 10,
						maxlength:10
   					  },
                      email: {
                        required: true,
                        email: true
                      },
					  referenceEmail: {
	                       user_email_not_same: true,
	                         email: true
	                      },
                      currentPassword: {
                        required: true,
                        minlength: 8
                      },
 					  password: {
                        required: true,
                        minlength: 8
                      },
					  confirmPassword: {
                        required: true,
						equalTo:"#password",
                        minlength: 8
                       },
					 companyName: "required",
                     companyWebsite: "required",
                     companyType: "required",
                     companySize: "required",
                     agree: "required",
					
	             },/*end of rules*/
                  messages: {
                    name: "Please enter your name",
                    mobile: "Please enter a valid mobile number",
                    currentPassword: {
                        required: "Please provide current password",
                        minlength: "Your password must be at least 8 characters long"
                    },
					password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 8 characters long"
                    },
					confirmPassword: {
                        required: "Please type password again",
                        minlength: "Your password must be at least 8 characters long"
                    },
                    email: "Please enter a valid email address",
                    companyName: "Please enter your company name",
                    companyWebsite: "Please enter your website address",
                    companyType: "Please select type of the company",
                    companySize: "Please select size of the company",
                    agree: "Please accept our policy"
                },/*end of msgs*/

                submitHandler: function(form) {
                    form.submit();
                }
            }/*end of validat function*/
		  );/*close of validate rsj*/
        }/*end of setup validation function*/
    }/*end of jquery util*/
 
    //when the dom has loaded setup form validation rules
$.validator.addMethod("user_email_not_same", function(value, element) {
	   return $('#referenceEmail').val() != $('#email').val()
	}, "* Reference email and Email should not match");
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });
 
})(jQuery, window, document);